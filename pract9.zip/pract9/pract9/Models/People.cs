﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;

namespace pract9.Models
{
    public class People
    {
        private string name;
        private double ves;
        public string Name { get; set; }
        public double Ves { get; set; }
        public string GetName()
        {
            return name;
        }
        public double GetVes()
        {
            return ves;
        }
        public void SetName(string value)
        {
            bool OnlyLet = true;
            // ключ. слово value - это то, что хотят свойству присвоить
            foreach (var ch in value)
            {
                if (!char.IsLetter(ch))
                {
                    OnlyLet = false;
                }
            }
            if (OnlyLet)
            {
                name = value;
            }
            else
            {
                Console.WriteLine($"{value}-неправильное имя!!!");
            }
        }
        public void SetVes(double value)
        {

            if (ves !<=0)
            {
                ves = value;
            }
            else
            {
                Console.WriteLine($"{value}-неправильный вес!!!");
            }
            if (ves > 100)
            {
                Console.WriteLine($"Вам нужно похудеть{ves}");
            }
            else if (ves < 40)
            {
                Console.WriteLine($"Вам нужно поправиться {ves}");
            }
        }


        public People(string PeopleName, double PeopleVes)
        {
            Name = PeopleName;
            Ves = PeopleVes;
        }

        


        public void SetPeopleName(string PeopleName)
        {
            bool OnlyLet = true;
            foreach (var ch in PeopleName)
            {
                if (!char.IsLetter(ch))
                {
                    OnlyLet = false;
                }
            }
            if (OnlyLet)
                name = PeopleName;
            else
                Console.WriteLine($"{PeopleName} - неправильное имя!!!");
        }

        public void Hello()
        {
            Console.WriteLine($"ПРИВЕТ, МЕНЯ ЗОВУТ {name},мой вес {ves}!!!!");
        }


    }
    
}
