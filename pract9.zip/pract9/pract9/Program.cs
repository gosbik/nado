﻿
using pract9.Models;


People vasy = new People("Васяг", 6.67);

vasy.SetName("Вася");
vasy.SetVes(5.96);
vasy.SetName("1234");
vasy.SetVes(78.96);
vasy.Hello();

